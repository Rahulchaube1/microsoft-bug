#!/usr/bin/env python3
"""
Real-Time Multi-Stage L4 TCP vs. L7 TLS/HTTP2 Synthetic Health Probe & Diagnostic Monitor
Targets Microsoft 365 / Exchange Online / Teams / Graph Endpoints (Incident EX1550543 & MO1550821).

Detects the exact "Zombie Server" anomaly observed during the November 12-13, 2026 outage:
Servers accept L4 TCP connections (SYN/ACK succeeds in ~25-40ms), fooling legacy L4 load-balancer
health checks, while the L7 secure-connection worker process hangs during TLS 1.3 handshake
(SSLWantRead / timeout -> HTTP 000 / curl exit 28).
"""

import socket
import ssl
import time
import json
import random
import argparse
import statistics
from dataclasses import dataclass, asdict
from typing import List, Optional, Dict

DEFAULT_M365_ENDPOINTS = [
    {"name": "Outlook Web / Exchange Front-Door", "host": "outlook.office365.com", "port": 443, "path": "/owa/healthcheck.htm"},
    {"name": "Outlook Consumer / Personal", "host": "outlook.live.com", "port": 443, "path": "/owa/"},
    {"name": "Microsoft Graph API Core", "host": "graph.microsoft.com", "port": 443, "path": "/v1.0/$metadata"},
    {"name": "Microsoft Teams Presence & Calendar", "host": "teams.microsoft.com", "port": 443, "path": "/"},
    {"name": "Microsoft 365 Admin & Status", "host": "status.cloud.microsoft", "port": 443, "path": "/"},
]

@dataclass
class ProbeResult:
    endpoint_name: str
    host: str
    resolved_ip: str
    timestamp_utc: float
    tcp_connected: bool
    tcp_latency_ms: float
    tls_handshake_completed: bool
    tls_latency_ms: float
    tls_protocol: Optional[str]
    tls_cipher: Optional[str]
    http_status: int
    total_latency_ms: float
    anomaly_classification: str
    error_detail: Optional[str]

class RealTimeL7ProbeEngine:
    """
    Executes two-stage decoupled socket + TLS + HTTP probing to distinguish:
      - HEALTHY: TCP + TLS + HTTP all complete within SLA thresholds
      - ZOMBIE_TLS_STALL (EX1550543 Signature): TCP connects fast (<150ms), TLS handshake times out or stalls
      - L7_GATEWAY_OVERLOAD: TCP + TLS succeed, HTTP returns 429/503/504
      - L4_UNREACHABLE: TCP connection refused or timed out
    """
    def __init__(self, timeout_sec: float = 5.0, tls_sla_ms: float = 1200.0):
        self.timeout_sec = timeout_sec
        self.tls_sla_ms = tls_sla_ms

    def probe_host(self, name: str, host: str, port: int = 443, path: str = "/") -> ProbeResult:
        ts = time.time()
        try:
            addr_info = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)
            resolved_ip = addr_info[0][4][0] if addr_info else "0.0.0.0"
        except Exception as e:
            return ProbeResult(
                endpoint_name=name, host=host, resolved_ip="DNS_FAIL", timestamp_utc=ts,
                tcp_connected=False, tcp_latency_ms=0.0, tls_handshake_completed=False,
                tls_latency_ms=0.0, tls_protocol=None, tls_cipher=None, http_status=0,
                total_latency_ms=0.0, anomaly_classification="DNS_RESOLUTION_FAILURE",
                error_detail=str(e)
            )

        # Stage 1: Raw TCP Handshake (L4)
        t0 = time.perf_counter()
        raw_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        raw_sock.settimeout(self.timeout_sec)
        try:
            raw_sock.connect((resolved_ip, port))
            tcp_ms = (time.perf_counter() - t0) * 1000.0
        except Exception as e:
            raw_sock.close()
            return ProbeResult(
                endpoint_name=name, host=host, resolved_ip=resolved_ip, timestamp_utc=ts,
                tcp_connected=False, tcp_latency_ms=0.0, tls_handshake_completed=False,
                tls_latency_ms=0.0, tls_protocol=None, tls_cipher=None, http_status=0,
                total_latency_ms=(time.perf_counter() - t0) * 1000.0,
                anomaly_classification="L4_TCP_UNREACHABLE",
                error_detail=str(e)
            )

        # Stage 2: Cryptographic TLS Handshake (L7 Secure Connection Worker Check)
        ctx = ssl.create_default_context()
        t_tls_start = time.perf_counter()
        try:
            tls_sock = ctx.wrap_socket(raw_sock, server_hostname=host, do_handshake_on_connect=False)
            tls_sock.settimeout(self.timeout_sec)
            tls_sock.do_handshake()
            tls_ms = (time.perf_counter() - t_tls_start) * 1000.0
            proto = tls_sock.version()
            cipher_info = tls_sock.cipher()
            cipher_name = cipher_info[0] if cipher_info else "UNKNOWN"
        except Exception as e:
            raw_sock.close()
            total_ms = (time.perf_counter() - t0) * 1000.0
            # Classic EX1550543 Zombie Server signature: TCP succeeded, TLS stalled!
            return ProbeResult(
                endpoint_name=name, host=host, resolved_ip=resolved_ip, timestamp_utc=ts,
                tcp_connected=True, tcp_latency_ms=round(tcp_ms, 2),
                tls_handshake_completed=False, tls_latency_ms=0.0,
                tls_protocol=None, tls_cipher=None, http_status=0,
                total_latency_ms=round(total_ms, 2),
                anomaly_classification="ZOMBIE_TLS_HANDSHAKE_EXHAUSTION_EX1550543",
                error_detail=f"TCP connected in {tcp_ms:.1f}ms but TLS handshake stalled: {e}"
            )

        # Stage 3: Minimal HTTP GET Liveness Check
        http_status = 0
        err_msg = None
        try:
            req = (
                f"HEAD {path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                f"User-Agent: M365-Resilience-Probe/2.0\r\n"
                f"Connection: close\r\n\r\n"
            ).encode("ascii")
            tls_sock.sendall(req)
            resp = tls_sock.recv(1024).decode("latin1", errors="replace")
            first_line = resp.splitlines()[0] if resp else ""
            parts = first_line.split()
            if len(parts) >= 2 and parts[1].isdigit():
                http_status = int(parts[1])
        except Exception as e:
            err_msg = str(e)
        finally:
            tls_sock.close()

        total_ms = (time.perf_counter() - t0) * 1000.0
        if http_status == 0:
            classification = "L7_HTTP_READ_TIMEOUT_AFTER_TLS"
        elif http_status in (429, 502, 503, 504):
            classification = f"L7_BACKEND_THROTTLED_HTTP_{http_status}"
        elif tls_ms > self.tls_sla_ms:
            classification = "DEGRADED_TLS_WORKER_SATURATION"
        else:
            classification = "HEALTHY_OPTIMAL"

        return ProbeResult(
            endpoint_name=name, host=host, resolved_ip=resolved_ip, timestamp_utc=ts,
            tcp_connected=True, tcp_latency_ms=round(tcp_ms, 2),
            tls_handshake_completed=True, tls_latency_ms=round(tls_ms, 2),
            tls_protocol=proto, tls_cipher=cipher_name, http_status=http_status,
            total_latency_ms=round(total_ms, 2),
            anomaly_classification=classification,
            error_detail=err_msg
        )

    def simulate_incident_ex1550543_cluster(self, num_nodes: int = 12, seed: int = 42) -> List[ProbeResult]:
        """
        Generates a deterministic forensic trace matching the real-world packet probe
        profile observed during Incident EX1550543 (303 probe rounds across Exchange IPs).
        """
        rng = random.Random(seed)
        results = []
        now = time.time()
        for i in range(num_nodes):
            ip = f"52.96.{100 + (i // 4)}.{10 + (i % 4) * 12}"
            r = rng.random()
            if r < 0.58:
                # 58% Zombie TLS Stall (TCP connects in 28-46ms, TLS times out at 6000ms, HTTP 000)
                tcp_ms = round(rng.uniform(26.0, 48.0), 2)
                results.append(ProbeResult(
                    endpoint_name="Outlook Web / Exchange Front-Door",
                    host="outlook.office365.com",
                    resolved_ip=ip,
                    timestamp_utc=now + i,
                    tcp_connected=True,
                    tcp_latency_ms=tcp_ms,
                    tls_handshake_completed=False,
                    tls_latency_ms=0.0,
                    tls_protocol=None,
                    tls_cipher=None,
                    http_status=0,
                    total_latency_ms=round(tcp_ms + 6000.0, 2),
                    anomaly_classification="ZOMBIE_TLS_HANDSHAKE_EXHAUSTION_EX1550543",
                    error_detail="TCP SYN/ACK OK; SSL_do_handshake timed out after 6000ms (HTTP 000)"
                ))
            elif r < 0.78:
                # 20% Severely degraded TLS saturation
                tcp_ms = round(rng.uniform(30.0, 55.0), 2)
                tls_ms = round(rng.uniform(1850.0, 4200.0), 2)
                results.append(ProbeResult(
                    endpoint_name="Microsoft Graph API Core",
                    host="graph.microsoft.com",
                    resolved_ip=ip,
                    timestamp_utc=now + i,
                    tcp_connected=True,
                    tcp_latency_ms=tcp_ms,
                    tls_handshake_completed=True,
                    tls_latency_ms=tls_ms,
                    tls_protocol="TLSv1.3",
                    tls_cipher="TLS_AES_256_GCM_SHA384",
                    http_status=503,
                    total_latency_ms=round(tcp_ms + tls_ms + 410.0, 2),
                    anomaly_classification="L7_BACKEND_THROTTLED_HTTP_503",
                    error_detail="Service Unavailable - Exchange mailbox proxy queue full"
                ))
            else:
                # 22% Healthy surviving or Teams real-time signaling node
                tcp_ms = round(rng.uniform(22.0, 38.0), 2)
                tls_ms = round(rng.uniform(45.0, 92.0), 2)
                results.append(ProbeResult(
                    endpoint_name="Microsoft Teams Signaling Fabric",
                    host="teams.microsoft.com",
                    resolved_ip=ip,
                    timestamp_utc=now + i,
                    tcp_connected=True,
                    tcp_latency_ms=tcp_ms,
                    tls_handshake_completed=True,
                    tls_latency_ms=tls_ms,
                    tls_protocol="TLSv1.3",
                    tls_cipher="TLS_AES_256_GCM_SHA384",
                    http_status=200,
                    total_latency_ms=round(tcp_ms + tls_ms + 35.0, 2),
                    anomaly_classification="HEALTHY_OPTIMAL",
                    error_detail=None
                ))
        return results

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="M365 L4/L7 TLS Handshake & Zombie Node Detector")
    parser.add_argument("--simulate-ex1550543", action="store_true", help="Run forensic simulation of EX1550543 cluster state")
    parser.add_argument("--live", action="store_true", help="Probe live M365 endpoints from current network")
    args = parser.parse_args()

    engine = RealTimeL7ProbeEngine(timeout_sec=5.0)
    if args.live:
        out = [asdict(engine.probe_host(ep["name"], ep["host"], ep["port"], ep["path"])) for ep in DEFAULT_M365_ENDPOINTS]
    else:
        out = [asdict(r) for r in engine.simulate_incident_ex1550543_cluster(num_nodes=12)]
    print(json.dumps(out, indent=2))
