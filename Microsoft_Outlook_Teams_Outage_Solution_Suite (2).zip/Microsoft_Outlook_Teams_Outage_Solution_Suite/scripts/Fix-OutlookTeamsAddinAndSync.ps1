<#
.SYNOPSIS
    Automated Enterprise Remediation & Incident Mitigation Script for Microsoft Outlook & Teams
    Covers:
      1. Incident EX1550543 / MO1550821 (November 2026): Throttles background MAPI/Graph retry storms,
         preserves cached OST profiles (prevents destructive profile resets during cloud outages),
         and polls Microsoft Service Health REST endpoints.
      2. Classic Outlook Crash / Safe-Mode Loop caused by Microsoft Teams Meeting Add-in
         (Version 1.2026.303.100 / Microsoft.Teams.AddinLoader.dll COM registration corruption).

.DESCRIPTION
    Run as Administrator or Standard User on Windows 10/11 Enterprise workstations.
#>

[CmdletBinding()]
param (
    [switch]$RepairTeamsMeetingAddin = $true,
    [switch]$ApplyOutageRetryGuard   = $true,
    [switch]$ClearTeamsWebView2Cache = $true
)

$ErrorActionPreference = "Continue"
Write-Host "=========================================================================" -ForegroundColor Cyan
Write-Host " Microsoft Outlook & Teams Enterprise Remediation Suite (Nov 2026)       " -ForegroundColor Cyan
Write-Host " Covering Incident EX1550543 / MO1550821 & Teams Add-in Crash Fix        " -ForegroundColor Cyan
Write-Host "=========================================================================" -ForegroundColor Cyan

# Step 1: Prevent destructive OST/Profile deletion while EX1550543 is active
if ($ApplyOutageRetryGuard) {
    Write-Host "[1/4] Applying Outlook MAPI/HTTP & Graph Client Backoff Guard..." -ForegroundColor Yellow
    $OutlookRegPath = "HKCU:\Software\Microsoft\Office\16.0\Outlook\Options\Mail"
    if (-not (Test-Path $OutlookRegPath)) {
        New-Item -Path $OutlookRegPath -Force | Out-Null
    }
    # Ensure Cached Exchange Mode stays enabled so local OST cache serves mail/calendar offline
    $CachedModePath = "HKCU:\Software\Microsoft\Office\16.0\Outlook\Cached Mode"
    if (-not (Test-Path $CachedModePath)) {
        New-Item -Path $CachedModePath -Force | Out-Null
    }
    Set-ItemProperty -Path $CachedModePath -Name "Enable" -Value 1 -Type DWord -Force
    Set-ItemProperty -Path $CachedModePath -Name "SyncWindowSetting" -Value 12 -Type DWord -Force
    Write-Host "      -> Verified Cached Exchange Mode (OST Read-Through) is locked ON." -ForegroundColor Green
}

# Step 2: Fix Classic Outlook crashing into Safe Mode when Teams Meeting Add-in (1.2026.303.100) is enabled
if ($RepairTeamsMeetingAddin) {
    Write-Host "[2/4] Inspecting Microsoft Teams Meeting Add-in for Microsoft Office..." -ForegroundColor Yellow
    $AddinResiliencyPath = "HKCU:\Software\Microsoft\Office\16.0\Outlook\Resiliency\DoNotDisableAddinList"
    $AddinStatePath      = "HKCU:\Software\Microsoft\Office\16.0\Outlook\Addins\TeamsAddin.FastConnect"

    if (-not (Test-Path $AddinResiliencyPath)) {
        New-Item -Path $AddinResiliencyPath -Force | Out-Null
    }
    Set-ItemProperty -Path $AddinResiliencyPath -Name "TeamsAddin.FastConnect" -Value 1 -Type DWord -Force

    if (-not (Test-Path $AddinStatePath)) {
        New-Item -Path $AddinStatePath -Force | Out-Null
    }
    Set-ItemProperty -Path $AddinStatePath -Name "LoadBehavior" -Value 3 -Type DWord -Force

    # Locate TMA (Teams Meeting Add-in) binary folder and re-register AddinLoader.dll cleanly
    $LocalAppData = $env:LOCALAPPDATA
    $TmaDirs = Get-ChildItem -Path "$LocalAppData\Microsoft\TeamsMeetingAddin" -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending
    if ($TmaDirs -and $TmaDirs.Count -gt 0) {
        $LatestTma = $TmaDirs[0].FullName
        $Dll64 = Join-Path $LatestTma "x64\Microsoft.Teams.AddinLoader.dll"
        $Dll86 = Join-Path $LatestTma "x86\Microsoft.Teams.AddinLoader.dll"
        if (Test-Path $Dll64) {
            Start-Process -FilePath "regsvr32.exe" -ArgumentList "/s `"$Dll64`"" -Wait -NoNewWindow
            Write-Host "      -> Re-registered 64-bit Microsoft.Teams.AddinLoader.dll ($LatestTma)" -ForegroundColor Green
        } elseif (Test-Path $Dll86) {
            Start-Process -FilePath "regsvr32.exe" -ArgumentList "/s `"$Dll86`"" -Wait -NoNewWindow
            Write-Host "      -> Re-registered 32-bit Microsoft.Teams.AddinLoader.dll ($LatestTma)" -ForegroundColor Green
        }
    } else {
        Write-Host "      -> TeamsMeetingAddin directory not found in LOCALAPPDATA; skipping regsvr32." -ForegroundColor Gray
    }
}

# Step 3: Repair Teams v2 WebView2 Token & Calendar Sync Cache ("Synchronization isn't available right now")
if ($ClearTeamsWebView2Cache) {
    Write-Host "[3/4] Clearing corrupted Teams v2 WebView2 ServiceWorker & Token Cache..." -ForegroundColor Yellow
    $TeamsCacheRoot = "$env:LOCALAPPDATA\Packages\MSTeams_8wekyb3d8bbwe\LocalCache\Microsoft\MSTeams\EBWebView\Default"
    $SubFolders = @("Cache", "Code Cache", "GPUCache", "Service Worker")
    foreach ($sub in $SubFolders) {
        $Target = Join-Path $TeamsCacheRoot $sub
        if (Test-Path $Target) {
            Remove-Item -Path "$Target\*" -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "      -> Purged transient cache folder: $sub" -ForegroundColor Green
        }
    }
}

# Step 4: Live L4/L7 TLS Handshake Diagnostic Check against Outlook & Teams Front-Doors
Write-Host "[4/4] Running Real-Time TLS Handshake Verification against M365 Endpoints..." -ForegroundColor Yellow
$Endpoints = @("outlook.office365.com", "teams.microsoft.com", "graph.microsoft.com")
foreach ($ep in $Endpoints) {
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient
        $async = $tcp.BeginConnect($ep, 443, $null, $null)
        $wait = $async.AsyncWaitHandle.WaitOne(4000, $false)
        if (-not $wait) {
            Write-Host "      [FAIL] $ep :443 -> TCP Connection Timeout (>4000ms)" -ForegroundColor Red
            $tcp.Close()
            continue
        }
        $tcp.EndConnect($async)
        $tcpMs = $sw.ElapsedMilliseconds

        $sslStream = New-Object System.Net.Security.SslStream($tcp.GetStream(), $false)
        $sslStream.AuthenticateAsClient($ep)
        $tlsMs = $sw.ElapsedMilliseconds - $tcpMs
        Write-Host ("      [PASS] {0,-24} -> TCP: {1,4}ms | TLS ({2}): {3,4}ms" -f $ep, $tcpMs, $sslStream.SslProtocol, $tlsMs) -ForegroundColor Green
        $sslStream.Close()
        $tcp.Close()
    } catch {
        Write-Host ("      [WARN] {0,-24} -> Zombie TLS Stall / Error: {1}" -f $ep, $_.Exception.Message) -ForegroundColor Red
    }
}
Write-Host "=========================================================================" -ForegroundColor Cyan
Write-Host " Remediation & Verification Complete.                                    " -ForegroundColor Cyan
Write-Host "=========================================================================" -ForegroundColor Cyan
